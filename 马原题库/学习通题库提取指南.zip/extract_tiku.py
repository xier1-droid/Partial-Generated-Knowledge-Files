#!/usr/bin/env python3
"""Extract question bank data from exported local HTML files.

The script is intended for HTML files you already have legitimate access to.
It focuses on exported Chaoxing homework/detail pages and can export:
- CSV
- JSON
- a review-friendly XLSX workbook

Usage examples:
  python extract_tiku.py --input "D:\path\to\作业详情.html" --output tiku.xlsx
  python extract_tiku.py --input html_dir --output tiku.xlsx --recursive
  python extract_tiku.py --input html_dir --output tiku.csv
  python extract_tiku.py --input html_dir --output tiku.json

Dependencies:
  HTML parsing requires: pip install beautifulsoup4
  XLSX export uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from html import escape, unescape
from pathlib import Path
from typing import Iterable, List, Optional
from zipfile import ZIP_DEFLATED, ZipFile

try:
    from bs4 import BeautifulSoup, Tag
except ImportError as exc:  # pragma: no cover - import-time failure is enough
    raise SystemExit(
        "Missing dependency: beautifulsoup4. Install it with: pip install beautifulsoup4"
    ) from exc


QUESTION_BLOCK_SELECTOR = ".TiMu .questionLi.singleQuesId, .questionLi.singleQuesId"
QUESTION_HEADER_SELECTOR = "h3.mark_name"
QUESTION_STEM_SELECTOR = "h3.mark_name .qtContent"
QUESTION_TYPE_SELECTOR = "h3.mark_name .colorShallow"
OPTION_SELECTOR = "ul.mark_letter li"
ANSWER_SELECTOR = ".rightAnswerContent"
MY_ANSWER_SELECTOR = ".stuAnswerContent"
ANALYSIS_SELECTOR = ".qtAnalysis"

OPTION_LABEL_RE = re.compile(r"^\s*([A-H])(?:[\.、．\)])\s*(.*)$")
QUESTION_NUMBER_RE = re.compile(r"^\s*(\d+)\.\s*")
QUESTION_TYPE_BRACKET_RE = re.compile(r"[\(（]\s*([^\(\)（）]+?)\s*[\)）]")
ANSWER_TEXT_RE = re.compile(r"^\s*(?:答案|正确答案)\s*[:：]\s*(.+?)\s*$", re.M)
ANALYSIS_TEXT_RE = re.compile(r"^\s*解析\s*[:：]\s*(.+?)\s*$", re.M | re.S)


@dataclass
class QuestionRecord:
    source_file: str
    source_id: str
    item_index: int
    question_number: str = ""
    question_type: str = ""
    question: str = ""
    option_a: str = ""
    option_b: str = ""
    option_c: str = ""
    option_d: str = ""
    option_e: str = ""
    option_f: str = ""
    my_answer: str = ""
    answer: str = ""
    result: str = ""
    analysis: str = ""


# -------------------------
# HTML extraction helpers
# -------------------------


def read_text_with_fallback(path: Path) -> str:
    data = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "gb18030", "gbk"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            pass
    return data.decode("utf-8", errors="ignore")


def normalize_text(text: str) -> str:
    text = unescape(text)
    text = text.replace("\r", "\n")
    text = text.replace("\u00a0", " ")
    text = re.sub(r"[\u3000\t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ ]{2,}", " ", text)
    return text.strip()


def extract_text(node: Optional[Tag]) -> str:
    if node is None:
        return ""
    return normalize_text(node.get_text(" ", strip=True))


def iter_input_files(inputs: List[str], recursive: bool) -> Iterable[Path]:
    for raw in inputs:
        path = Path(raw)
        if path.is_file():
            if path.suffix.lower() in {".html", ".htm"}:
                yield path
            continue
        if path.is_dir():
            pattern = "**/*" if recursive else "*"
            for child in sorted(path.glob(pattern)):
                if child.is_file() and child.suffix.lower() in {".html", ".htm"}:
                    yield child


def clean_question_type(text: str) -> str:
    text = normalize_text(text)
    text = text.strip("()（）")
    if text and text not in {"单选题", "多选题", "判断题", "填空题", "简答题"}:
        match = QUESTION_TYPE_BRACKET_RE.search(text)
        if match:
            return match.group(1).strip()
    return text


def parse_option_text(text: str) -> tuple[str, str]:
    text = normalize_text(text)
    match = OPTION_LABEL_RE.match(text)
    if match:
        return match.group(1).upper(), normalize_text(match.group(2))
    if len(text) >= 2 and text[0].upper() in "ABCDEFGH" and text[1] in ".、．)":
        return text[0].upper(), normalize_text(text[2:])
    return "", text


def normalize_answer_key(text: str) -> str:
    text = normalize_text(text).upper()
    letters = [ch for ch in text if ch in "ABCDEFGH"]
    if letters:
        dedup: List[str] = []
        for ch in letters:
            if ch not in dedup:
                dedup.append(ch)
        return "".join(dedup)
    return text


def parse_answer_text(text: str) -> str:
    text = normalize_text(text)
    if not text:
        return ""
    match = ANSWER_TEXT_RE.search(text)
    if match:
        text = match.group(1)
    return normalize_answer_key(text)


def parse_analysis_text(text: str) -> str:
    text = normalize_text(text)
    match = ANALYSIS_TEXT_RE.search(text)
    if match:
        return normalize_text(match.group(1))
    return text


def compare_answers(my_answer: str, answer: str) -> str:
    my_key = normalize_answer_key(my_answer)
    answer_key = normalize_answer_key(answer)
    if not my_key:
        return "未答"
    if my_key == answer_key:
        return "正确"
    return "错误"


def clean_question_text(text: str) -> str:
    text = normalize_text(text)
    text = QUESTION_NUMBER_RE.sub("", text)
    text = re.sub(r"^[\(（]\s*(?:单选题|多选题|判断题|填空题|简答题)\s*[\)）]\s*", "", text)
    return text.strip()


def row_height_for_record(record: QuestionRecord) -> float:
    lengths = [
        len(record.question),
        len(record.analysis),
        len(record.option_a),
        len(record.option_b),
        len(record.option_c),
        len(record.option_d),
        len(record.option_e),
        len(record.option_f),
    ]
    longest = max(lengths) if lengths else 0
    lines = max(1, math.ceil(longest / 18))
    lines = min(lines, 6)
    return 18 + (lines - 1) * 14


def dedupe_records(records: List[QuestionRecord]) -> List[QuestionRecord]:
    deduped: List[QuestionRecord] = []
    seen = set()
    for record in records:
        key = (
            record.source_file,
            record.question_number,
            record.question,
            record.option_a,
            record.option_b,
            record.option_c,
            record.option_d,
            record.answer,
            record.my_answer,
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(record)
    return deduped


def extract_record_from_block(block: Tag, source_file: str, item_index: int, args: argparse.Namespace) -> QuestionRecord:
    source_id = block.get("id", "")
    raw_text = extract_text(block)

    header_node = block.select_one(args.header_selector or QUESTION_HEADER_SELECTOR)
    stem_node = block.select_one(args.question_selector or QUESTION_STEM_SELECTOR)
    type_node = block.select_one(QUESTION_TYPE_SELECTOR)
    answer_node = block.select_one(args.answer_selector or ANSWER_SELECTOR)
    my_answer_node = block.select_one(MY_ANSWER_SELECTOR)
    analysis_node = block.select_one(args.analysis_selector or ANALYSIS_SELECTOR)

    header_text = extract_text(header_node)
    stem_text = extract_text(stem_node)
    type_text = extract_text(type_node)
    answer_text = extract_text(answer_node)
    my_answer_text = extract_text(my_answer_node)
    analysis_text = extract_text(analysis_node)

    question_number = ""
    if header_text:
        match = QUESTION_NUMBER_RE.match(header_text)
        if match:
            question_number = match.group(1)

    question_type = clean_question_type(type_text)
    if not question_type and header_text:
        match = QUESTION_TYPE_BRACKET_RE.search(header_text)
        if match:
            question_type = match.group(1).strip()

    question = stem_text or clean_question_text(header_text)
    if not question:
        question = clean_question_text(raw_text)

    options: dict[str, str] = {}
    option_nodes = block.select(args.option_selector or OPTION_SELECTOR)
    for node in option_nodes:
        label, value = parse_option_text(extract_text(node))
        if label:
            options[label] = value

    answer = parse_answer_text(answer_text or raw_text)
    my_answer = parse_answer_text(my_answer_text)
    result = compare_answers(my_answer, answer)

    return QuestionRecord(
        source_file=source_file,
        source_id=source_id,
        item_index=item_index,
        question_number=question_number,
        question_type=question_type,
        question=question,
        option_a=options.get("A", ""),
        option_b=options.get("B", ""),
        option_c=options.get("C", ""),
        option_d=options.get("D", ""),
        option_e=options.get("E", ""),
        option_f=options.get("F", ""),
        my_answer=my_answer,
        answer=answer,
        result=result,
        analysis=parse_analysis_text(analysis_text),
    )


def extract_records_from_html(html: str, source_file: str, args: argparse.Namespace) -> List[QuestionRecord]:
    soup = BeautifulSoup(html, "html.parser")

    if args.item_selector:
        blocks = soup.select(args.item_selector)
    else:
        blocks = soup.select(QUESTION_BLOCK_SELECTOR)
        if not blocks:
            blocks = soup.select(".questionLi.singleQuesId")
        if not blocks:
            blocks = soup.select(".questionLi")

    if not blocks:
        blocks = [soup.body or soup]

    records: List[QuestionRecord] = []
    for index, block in enumerate(blocks, start=1):
        if not isinstance(block, Tag):
            continue
        record = extract_record_from_block(block, source_file, index, args)
        if record.question or record.answer or record.my_answer:
            records.append(record)

    return dedupe_records(records)


# -------------------------
# CSV / JSON export
# -------------------------


def write_csv(records: List[QuestionRecord], output: Path) -> None:
    fieldnames = list(asdict(records[0]).keys()) if records else list(asdict(QuestionRecord("", "", 0)).keys())
    with output.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            writer.writerow(asdict(record))


def write_json(records: List[QuestionRecord], output: Path) -> None:
    payload = [asdict(record) for record in records]
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


# -------------------------
# XLSX export helpers
# -------------------------


XLSX_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_TYPES_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
DOC_PROPS_NS = "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
CORE_PROPS_NS = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
DC_NS = "http://purl.org/dc/elements/1.1/"
DCTERMS_NS = "http://purl.org/dc/terms/"
XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"


def col_letter(index: int) -> str:
    result = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        result = chr(65 + remainder) + result
    return result


def cell_ref(row: int, col: int) -> str:
    return f"{col_letter(col)}{row}"


def xml_cell_text(value: str) -> str:
    text = escape(value, {'"': "&quot;"})
    if not text:
        return ""
    if value != value.strip() or "\n" in value or "\r" in value:
        return f'<is><t xml:space="preserve">{text}</t></is>'
    return f"<is><t>{text}</t></is>"


def make_inline_string_cell(ref: str, value: str, style_id: Optional[int] = None) -> str:
    if value is None or value == "":
        return ""
    attrs = [f'r="{ref}"', 't="inlineStr"']
    if style_id is not None:
        attrs.append(f's="{style_id}"')
    return f"<c {' '.join(attrs)}>{xml_cell_text(value)}</c>"


def make_number_cell(ref: str, value: float | int, style_id: Optional[int] = None) -> str:
    attrs = [f'r="{ref}"']
    if style_id is not None:
        attrs.append(f's="{style_id}"')
    return f"<c {' '.join(attrs)}><v>{value}</v></c>"


def build_styles_xml() -> str:
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="{XLSX_NS}">
  <numFmts count="1">
    <numFmt numFmtId="164" formatCode="0.0%"/>
  </numFmts>
  <fonts count="2">
    <font>
      <sz val="11"/>
      <color rgb="FF1F1F1F"/>
      <name val="Calibri"/>
      <family val="2"/>
    </font>
    <font>
      <b/>
      <sz val="11"/>
      <color rgb="FFFFFFFF"/>
      <name val="Calibri"/>
      <family val="2"/>
    </font>
  </fonts>
  <fills count="6">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFD9EAD3"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFF4CCCC"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFCE5CD"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="1">
    <border>
      <left/><right/><top/><bottom/><diagonal/>
    </border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="7">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1">
      <alignment vertical="top" wrapText="1"/>
    </xf>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="0" xfId="0" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="5" borderId="0" xfId="0" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
  </cellXfs>
  <cellStyles count="1">
    <cellStyle name="Normal" xfId="0" builtinId="0"/>
  </cellStyles>
  <dxfs count="0"/>
  <tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>
</styleSheet>
'''


def build_workbook_xml(sheet_names: List[str]) -> str:
    sheets_xml = []
    for idx, name in enumerate(sheet_names, start=1):
        sheets_xml.append(f'<sheet name="{escape(name)}" sheetId="{idx}" r:id="rId{idx}"/>')
    sheets_joined = "\n    ".join(sheets_xml)
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="{XLSX_NS}" xmlns:r="{REL_NS}">
  <bookViews>
    <workbookView activeTab="0"/>
  </bookViews>
  <sheets>
    {sheets_joined}
  </sheets>
</workbook>
'''


def build_workbook_rels_xml(sheet_count: int) -> str:
    rels = []
    for idx in range(1, sheet_count + 1):
        rels.append(
            f'<Relationship Id="rId{idx}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{idx}.xml"/>'
        )
    rels.append(
        f'<Relationship Id="rId{sheet_count + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
    )
    rels_joined = "\n    ".join(rels)
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="{PKG_REL_NS}">
    {rels_joined}
</Relationships>
'''


def build_root_rels_xml() -> str:
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="{PKG_REL_NS}">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>
'''


def build_content_types_xml(sheet_count: int) -> str:
    overrides = []
    for idx in range(1, sheet_count + 1):
        overrides.append(
            f'<Override PartName="/xl/worksheets/sheet{idx}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
    overrides.extend(
        [
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
            '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
        ]
    )
    overrides_joined = "\n  ".join(overrides)
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="{CONTENT_TYPES_NS}">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  {overrides_joined}
</Types>
'''


def build_core_props_xml(title: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="{CORE_PROPS_NS}" xmlns:dc="{DC_NS}" xmlns:dcterms="{DCTERMS_NS}" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="{XSI_NS}">
  <dc:title>{escape(title)}</dc:title>
  <dc:creator>Codex</dc:creator>
  <cp:lastModifiedBy>Codex</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">{stamp}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">{stamp}</dcterms:modified>
</cp:coreProperties>
'''


def build_app_props_xml(sheet_names: List[str]) -> str:
    titles = "".join(f"<vt:lpstr>{escape(name)}</vt:lpstr>" for name in sheet_names)
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="{DOC_PROPS_NS}" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>Microsoft Excel</Application>
  <DocSecurity>0</DocSecurity>
  <ScaleCrop>false</ScaleCrop>
  <HeadingPairs>
    <vt:vector size="2" baseType="variant">
      <vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant>
      <vt:variant><vt:i4>{len(sheet_names)}</vt:i4></vt:variant>
    </vt:vector>
  </HeadingPairs>
  <TitlesOfParts>
    <vt:vector size="{len(sheet_names)}" baseType="lpstr">
      {titles}
    </vt:vector>
  </TitlesOfParts>
  <Company></Company>
  <LinksUpToDate>false</LinksUpToDate>
  <SharedDoc>false</SharedDoc>
  <HyperlinksChanged>false</HyperlinksChanged>
  <AppVersion>16.0000</AppVersion>
</Properties>
'''


def build_review_rows(records: List[QuestionRecord]) -> List[List[str]]:
    rows: List[List[str]] = []
    for idx, record in enumerate(records, start=1):
        rows.append([
            str(idx),
            Path(record.source_file).name,
            record.question_number,
            record.question_type,
            record.question,
            record.option_a,
            record.option_b,
            record.option_c,
            record.option_d,
            record.option_e,
            record.option_f,
            record.my_answer,
            record.answer,
            record.result,
            record.analysis,
        ])
    return rows


def row_height_for_text_row(values: List[str]) -> float:
    lengths = [len(v or "") for v in values]
    longest = max(lengths) if lengths else 0
    lines = max(1, math.ceil(longest / 22))
    lines = min(lines, 6)
    return 18 + (lines - 1) * 14


def make_row_xml(row_num: int, values: List[str], style_selector, row_height: Optional[float] = None) -> str:
    attrs = [f'r="{row_num}"']
    if row_height is not None:
        attrs.append(f'ht="{row_height:.1f}"')
        attrs.append('customHeight="1"')
    cells = []
    for col_num, value in enumerate(values, start=1):
        if value is None or value == "":
            continue
        ref = cell_ref(row_num, col_num)
        style_id = style_selector(col_num, value)
        cells.append(make_inline_string_cell(ref, str(value), style_id))
    return f"<row {' '.join(attrs)}>{''.join(cells)}</row>"


def build_table_sheet_xml(headers: List[str], rows: List[List[str]], column_widths: List[float]) -> str:
    last_col = col_letter(len(headers))
    last_row = len(rows) + 1

    def style_selector(col_num: int, value: str) -> int:
        if col_num in {1, 2, 3, 4, 12, 13}:
            return 2
        if col_num == 14:
            if value == "正确":
                return 3
            if value == "错误":
                return 4
            return 5
        return 0

    cols_xml = "".join(
        f'<col min="{idx}" max="{idx}" width="{width}" customWidth="1"/>'
        for idx, width in enumerate(column_widths, start=1)
    )

    header_cells = []
    for col_num, header in enumerate(headers, start=1):
        header_cells.append(make_inline_string_cell(cell_ref(1, col_num), header, 1))
    header_row = f'<row r="1" ht="22" customHeight="1">{"".join(header_cells)}</row>'

    data_rows = []
    for row_num, values in enumerate(rows, start=2):
        height = row_height_for_text_row(values)
        data_rows.append(make_row_xml(row_num, values, style_selector, height))

    filter_xml = f'<autoFilter ref="A1:{last_col}{last_row}"/>' if rows else ""
    sheet_data = header_row + "".join(data_rows)

    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="{XLSX_NS}" xmlns:r="{REL_NS}">
  <sheetViews>
    <sheetView workbookViewId="0">
      <pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>
      <selection pane="bottomLeft" activeCell="A2" sqref="A2"/>
    </sheetView>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="18"/>
  <cols>{cols_xml}</cols>
  <sheetData>{sheet_data}</sheetData>
  {filter_xml}
</worksheet>
'''


def build_summary_sheet_xml(records: List[QuestionRecord]) -> str:
    total = len(records)
    correct = sum(1 for r in records if r.result == "正确")
    wrong = sum(1 for r in records if r.result == "错误")
    blank = sum(1 for r in records if r.result == "未答")
    accuracy = (correct / total) if total else 0.0

    type_stats = defaultdict(lambda: {"total": 0, "correct": 0, "wrong": 0, "blank": 0})
    for record in records:
        key = record.question_type or "未识别"
        bucket = type_stats[key]
        bucket["total"] += 1
        if record.result == "正确":
            bucket["correct"] += 1
        elif record.result == "错误":
            bucket["wrong"] += 1
        else:
            bucket["blank"] += 1

    type_rows = sorted(type_stats.items(), key=lambda item: (-item[1]["total"], item[0]))

    def summary_value_row(row_num: int, label1: str, value1: int, label2: str = "", value2: Optional[int] = None) -> str:
        cells = [
            make_inline_string_cell(f"A{row_num}", label1, 1),
            make_number_cell(f"B{row_num}", value1, 2),
        ]
        if label2:
            cells.append(make_inline_string_cell(f"D{row_num}", label2, 1))
        if value2 is not None:
            cells.append(make_number_cell(f"E{row_num}", value2, 2))
        return f'<row r="{row_num}" ht="22" customHeight="1">{"".join(cells)}</row>'

    rows: List[str] = []
    rows.append('<row r="1" ht="24" customHeight="1">' + make_inline_string_cell("A1", "题库复习汇总", 1) + '</row>')
    rows.append(summary_value_row(3, "总题数", total, "正确数", correct))
    rows.append(summary_value_row(4, "错误数", wrong, "未答数", blank))
    rows.append(
        '<row r="5" ht="22" customHeight="1">'
        + make_inline_string_cell("A5", "正确率", 1)
        + make_number_cell("B5", accuracy, 6)
        + '</row>'
    )

    rows.append(
        '<row r="8" ht="22" customHeight="1">'
        + "".join(
            [
                make_inline_string_cell("A8", "题型", 1),
                make_inline_string_cell("B8", "题数", 1),
                make_inline_string_cell("C8", "正确数", 1),
                make_inline_string_cell("D8", "错误数", 1),
                make_inline_string_cell("E8", "未答数", 1),
                make_inline_string_cell("F8", "正确率", 1),
            ]
        )
        + '</row>'
    )

    for offset, (qtype, bucket) in enumerate(type_rows, start=9):
        q_total = bucket["total"]
        q_correct = bucket["correct"]
        q_wrong = bucket["wrong"]
        q_blank = bucket["blank"]
        q_acc = (q_correct / q_total) if q_total else 0.0
        rows.append(
            f'<row r="{offset}" ht="22" customHeight="1">'
            + "".join(
                [
                    make_inline_string_cell(f"A{offset}", qtype, 0),
                    make_number_cell(f"B{offset}", q_total, 2),
                    make_number_cell(f"C{offset}", q_correct, 2),
                    make_number_cell(f"D{offset}", q_wrong, 2),
                    make_number_cell(f"E{offset}", q_blank, 2),
                    make_number_cell(f"F{offset}", q_acc, 6),
                ]
            )
            + '</row>'
        )

    cols_xml = (
        '<col min="1" max="1" width="20" customWidth="1"/>'
        '<col min="2" max="2" width="12" customWidth="1"/>'
        '<col min="3" max="3" width="12" customWidth="1"/>'
        '<col min="4" max="4" width="12" customWidth="1"/>'
        '<col min="5" max="5" width="12" customWidth="1"/>'
        '<col min="6" max="6" width="12" customWidth="1"/>'
    )

    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="{XLSX_NS}" xmlns:r="{REL_NS}">
  <sheetViews>
    <sheetView workbookViewId="0">
      <selection activeCell="A1" sqref="A1"/>
    </sheetView>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="18"/>
  <cols>{cols_xml}</cols>
  <sheetData>{''.join(rows)}</sheetData>
</worksheet>
'''


def write_xlsx(records: List[QuestionRecord], output: Path) -> None:
    sheet_names = ["复习题库", "错题本", "汇总"]
    headers = [
        "序号",
        "来源文件",
        "题号",
        "题型",
        "题目",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "我的答案",
        "正确答案",
        "结果",
        "解析",
    ]
    widths = [8, 20, 8, 10, 40, 18, 18, 18, 18, 18, 18, 12, 12, 10, 40]

    review_rows = build_review_rows(records)
    wrong_rows = [row for row in review_rows if row[13] != "正确"]

    sheet_xmls = [
        build_table_sheet_xml(headers, review_rows, widths),
        build_table_sheet_xml(headers, wrong_rows, widths),
        build_summary_sheet_xml(records),
    ]

    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, "w", compression=ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", build_content_types_xml(len(sheet_xmls)))
        zf.writestr("_rels/.rels", build_root_rels_xml())
        zf.writestr("xl/workbook.xml", build_workbook_xml(sheet_names))
        zf.writestr("xl/_rels/workbook.xml.rels", build_workbook_rels_xml(len(sheet_xmls)))
        zf.writestr("xl/styles.xml", build_styles_xml())
        zf.writestr("xl/worksheets/sheet1.xml", sheet_xmls[0])
        zf.writestr("xl/worksheets/sheet2.xml", sheet_xmls[1])
        zf.writestr("xl/worksheets/sheet3.xml", sheet_xmls[2])
        zf.writestr("docProps/core.xml", build_core_props_xml("题库复习导出"))
        zf.writestr("docProps/app.xml", build_app_props_xml(sheet_names))


# -------------------------
# CLI
# -------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract question bank data from exported HTML files.")
    parser.add_argument("--input", nargs="+", required=True, help="HTML file(s) or directory/directories")
    parser.add_argument("--output", required=True, help="Output file path, e.g. tiku.xlsx or tiku.csv")
    parser.add_argument(
        "--format",
        choices=["xlsx", "csv", "json"],
        default="",
        help="Output format. If omitted, it is inferred from the output suffix.",
    )
    parser.add_argument("--recursive", action="store_true", help="Search input directories recursively")
    parser.add_argument("--item-selector", default="", help="CSS selector for one question block")
    parser.add_argument("--header-selector", default="", help="CSS selector for the question header inside a block")
    parser.add_argument("--question-selector", default="", help="CSS selector for the question stem inside a block")
    parser.add_argument("--option-selector", default="", help="CSS selector for option nodes inside a block")
    parser.add_argument("--answer-selector", default="", help="CSS selector for the answer inside a block")
    parser.add_argument("--analysis-selector", default="", help="CSS selector for the analysis inside a block")
    return parser


def infer_format(output: Path, explicit_format: str) -> str:
    if explicit_format:
        return explicit_format
    suffix = output.suffix.lower()
    if suffix in {".xlsx", ".csv", ".json"}:
        return suffix.lstrip(".")
    return "xlsx"


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    input_files = list(iter_input_files(args.input, args.recursive))
    if not input_files:
        print("No HTML files found in the given input path(s).", file=sys.stderr)
        return 1

    output_path = Path(args.output)
    output_format = infer_format(output_path, args.format)

    all_records: List[QuestionRecord] = []
    for html_path in input_files:
        html = read_text_with_fallback(html_path)
        records = extract_records_from_html(html, str(html_path), args)
        all_records.extend(records)

    all_records = dedupe_records(all_records)

    if output_format == "csv":
        write_csv(all_records, output_path)
    elif output_format == "json":
        write_json(all_records, output_path)
    else:
        write_xlsx(all_records, output_path)

    print(f"Extracted {len(all_records)} record(s) to {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
